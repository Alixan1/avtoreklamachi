import aiohttp
import json
import logging
from config import RASMIYPAY_SHOP_ID, RASMIYPAY_SHOP_KEY

logger = logging.getLogger(__name__)

class RasmiyPayClient:
    BASE_URL = "https://xspin.uz/api"

    @staticmethod
    async def create_order(amount: int):
        """
        Create a new payment order.
        Returns (success, data/message)
        """
        if not RASMIYPAY_SHOP_ID or not RASMIYPAY_SHOP_KEY:
            return False, "API keys not configured"

        url = f"{RasmiyPayClient.BASE_URL}?method=create"
        payload = {
            "shop_id": RASMIYPAY_SHOP_ID,
            "shop_key": RASMIYPAY_SHOP_KEY,
            "amount": amount
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload) as resp:
                    if resp.status != 200:
                        return False, f"HTTP Error: {resp.status}"
                    
                    data = await resp.json()
                    
                    if data.get("status") == "success":
                        return True, data
                    else:
                        return False, data.get("message", "Unknown error")
        except Exception as e:
            logger.error(f"RasmiyPay Create Order Error: {e}")
            return False, str(e)

    @staticmethod
    async def check_order(order_code: str):
        """
        Check status of an order.
        Returns (success, data/message)
        """
        url = f"{RasmiyPayClient.BASE_URL}?method=check&order={order_code}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status != 200:
                        return False, f"HTTP Error: {resp.status}"
                    
                    data = await resp.json()
                    
                    if data.get("status") == "success":
                        return True, data["data"]
                    else:
                        return False, data.get("message", "Unknown error")
        except Exception as e:
            logger.error(f"RasmiyPay Check Order Error: {e}")
            return False, str(e)

    @staticmethod
    async def get_shop_info():
        # Implementation if needed
        pass
