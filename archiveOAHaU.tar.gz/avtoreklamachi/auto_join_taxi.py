import asyncio
import os
import glob
import logging
import urllib.parse
import aiohttp
from telethon import TelegramClient
from telethon.tl.functions.contacts import SearchRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import Channel
from telethon.errors import FloodWaitError

import random

# Config
API_ID = 26640989
API_HASH = "b4aa4e101740c497334751430030238d"
SESSION_DIR = r"C:\Users\ALIXAN\OneDrive\Desktop\project\avtoreklamachi\sessions\realislomovv"
AI_API_URL = "https://apis.prexzyvilla.site/ai/chat"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("TaxiJoiner")

KEYWORDS = [
    "Toshkent Taxi", "Andijon Taxi", "Farg'ona Taxi", "Namangan Taxi", 
    "Vodiy Taxi", "Samarqand Taxi", "Buxoro Taxi", "Xorazm Taxi",
    "Qashqadaryo Taxi", "Surxondaryo Taxi", "Navoiy Taxi", "Jizzax Taxi",
    "Sirdaryo Taxi", "Yuk Tashish", "Kirakashlar", "Pochta Uzb",
    "Pitak Taxi", "Mejdugorod Taxi"
]

async def get_session_file():
    files = glob.glob(os.path.join(SESSION_DIR, "*.session"))
    if not files:
        raise FileNotFoundError("Session fayl topilmadi!")
    return files[0]

async def ask_ai(title, about):
    """AI dan guruh haqida so'rash"""
    prompt = (
        f"Analyze this telegram group:\n"
        f"Title: {title}\n"
        f"Description: {about}\n"
        "Question: Is this a Taxi/Ride-sharing/Delivery/Freight group in Uzbekistan? "
        "Answer ONLY 'HA' (Yes) or 'YOQ' (No). "
        "Rules: Ignore religious, political, porn, or spam groups. Only transport/logistics."
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            # New Endpoint: https://apis.prexzyvilla.site/ai/chat?prompt=...
            encoded_prompt = urllib.parse.quote(prompt)
            url = f"{AI_API_URL}?prompt={encoded_prompt}&model=gpt-4"
            
            try:
                # 1. Try GET (User provided format)
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return _parse_ai_response(data, title)
                    else:
                        err = await resp.text()
                        logger.warning(f"GET {resp.status}: {err[:100]}")
                        
            except Exception as e:
                logger.warning(f"GET Request failed: {e}")
                
    except Exception as e:
        logger.error(f"AI Connection Error: {e}")
    
    return False

def _parse_ai_response(data, title):
    answer = ""
    if isinstance(data, dict):
        answer = data.get('answer') or data.get('response') or data.get('result') or data.get('data') or str(data)
    else:
        answer = str(data)
        
    logger.info(f"🤖 AI ({title}): {answer}")
    
    answ_upper = str(answer).upper()
    return "HA" in answ_upper or "YES" in answ_upper

async def main():
    session_path = await get_session_file()
    logger.info(f"Session: {session_path}")
    
    client = TelegramClient(session_path, API_ID, API_HASH)
    await client.connect()
    
    if not await client.is_user_authorized():
        logger.error("Session yaroqsiz yoki avtorizatsiya o'tmagan!")
        return

    me = await client.get_me()
    logger.info(f"Kirildi: {me.first_name} (ID: {me.id})")
    
    joined_count = 0
    
    try:
        for keyword in KEYWORDS:
            logger.info(f"🔍 Qidirilmoqda: {keyword}")
            
            try:
                # Global Search
                result = await client(SearchRequest(
                    q=keyword,
                    limit=10 
                ))
                
                for chat in result.chats:
                    # Faqat Channel/Supergroup
                    if not isinstance(chat, Channel):
                        continue
                    
                    # Already joined?
                    if chat.left:
                        # Tekshirish
                        title = chat.title
                        about = getattr(chat, 'about', '') or '' # Ba'zan username bo'lishi mumkin
                        
                        logger.info(f"Tekshirilmoqda: {title}")
                        
                        # AI Check
                        is_safe = await ask_ai(title, about)
                        
                        if is_safe:
                            logger.info(f"✅ AI Tasdiqladi! Qo'shilmoqda: {title}")
                            try:
                                await client(JoinChannelRequest(chat))
                                joined_count += 1
                                logger.info(f"🎉 Muvaffaqiyatli qo'shildi! ({joined_count})")
                                
                                # Random delay 2-5 daqiqa (FloodWait oldini olish uchun)
                                wait_time = random.randint(120, 300)
                                logger.info(f"⏳ Kutish: {wait_time}s...")
                                await asyncio.sleep(wait_time) 
                                
                            except FloodWaitError as e:
                                logger.warning(f"FloodWait: {e.seconds}s kuting... (Telegram cheklovi)")
                                await asyncio.sleep(e.seconds)
                            except Exception as join_e:
                                logger.error(f"Qo'shilishda xato: {join_e}")
                        else:
                            logger.info(f"❌ AI Rad etdi: {title}")
                            
            except Exception as e:
                logger.error(f"Qidiruv xatosi ({keyword}): {e}")
            
            # Har bir kalit so'z so'ngida kichik tanaffus
            search_wait = random.randint(10, 20)
            logger.info(f"Keyingi qidiruv {search_wait}s dan so'ng...")
            await asyncio.sleep(search_wait)
            
    finally:
        await client.disconnect()
        logger.info("Tugadi.")

if __name__ == "__main__":
    asyncio.run(main())
