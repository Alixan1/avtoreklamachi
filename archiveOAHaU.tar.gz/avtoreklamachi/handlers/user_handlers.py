from aiogram import Router, F, types, Bot
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from database.db import get_db_connection
from aiogram.types import ReplyKeyboardRemove, InlineKeyboardMarkup, WebAppInfo
from keyboards.user_kb import (
    main_menu_inline_kb, ads_menu_kb, back_kb, 
    simple_intervals_kb, group_method_kb, 
    folders_list_kb, confirm_start_kb, subscription_packages_kb,
    payment_methods_kb
)
from utils.helpers import ensure_user, has_active_sub, get_not_joined_channels, get_settings_value
from config import ADMIN_ID, TAGLINE, API_ID, API_HASH, WEBAPP_URL
from datetime import datetime, timedelta
import os
import asyncio
from telethon import TelegramClient
from telethon.sessions import StringSession
from utils.joiner import start_join_task
from utils.states import MsgStates, AccountStates, SimpleFlow, PaymentStates, ScraperStates
import logging

# Logger init
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = Router()

# ==================== SAFE HELPERS ====================
async def safe_edit(cb: types.CallbackQuery, text: str, reply_markup=None, **kwargs):
    """Xavfsiz xabar tahrirlash - xatoliklarni yutadi"""
    try:
        await cb.message.edit_text(text, reply_markup=reply_markup, **kwargs)
    except Exception:
        pass  # Xabar o'zgarmagan yoki boshqa xatolik

async def safe_answer(cb: types.CallbackQuery, text: str = None, **kwargs):
    """Xavfsiz callback javob - xatoliklarni yutadi"""
    try:
        await cb.answer(text, **kwargs)
    except Exception:
        pass  # Query eskirgan

# ==================== BOSH MENYU KEYBOARD ====================
def start_menu_kb(has_sub: bool = False, is_admin: bool = False) -> InlineKeyboardMarkup:
    """Bosh menyu - 3 ta usul: Oson, Pro, WebApp"""
    kb = InlineKeyboardBuilder()
    
    if has_sub:
        # Obuna bor - 3 ta usul
        kb.button(text="🚀 Oson Usul (Yangi)", callback_data="easy_mode")
        kb.button(text="💼 Pro Usul (Ko'proq)", callback_data="pro_mode")
        if WEBAPP_URL:
            kb.button(text="📱 WebApp", web_app=WebAppInfo(url=WEBAPP_URL))
        kb.button(text="🧾 Mening Reklamalarim", callback_data="ads_list")   
        kb.button(text="�👤 Profilim", callback_data="profile")
        kb.button(text="🔗 Referallar", callback_data="referrals_menu")
        kb.button(text="🔗 Akkauntlar", callback_data="acc_menu")
        if is_admin:
            kb.button(text="⚙️ Admin Panel", callback_data="admin_panel")
        kb.adjust(2)
    else:
        # Obuna yo'q
        kb.button(text="🎁 3 Kun TEKIN", callback_data="get_trial")
        kb.button(text="💎 VIP Obuna", callback_data="buy_sub")
        kb.button(text="🔗 Referallar", callback_data="referrals_menu")
        kb.button(text="👤 Profilim", callback_data="profile")
        kb.button(text="🆘 Yordam", callback_data="support")
        if is_admin:
            kb.button(text="⚙️ Admin Panel", callback_data="admin_panel")
        kb.adjust(2)
    
    return kb.as_markup()

# ==================== /START ====================
@router.message(Command("start"))
async def cmd_start(message: types.Message, bot: Bot, state: FSMContext):
    await state.clear()
    await ensure_user(message.from_user.id, message.from_user.full_name, message.from_user.username)
    
    # Referral check
    args = message.text.split()
    if len(args) > 1:
        ref_id = args[1]
        if ref_id.isdigit() and int(ref_id) != message.from_user.id:
            try:
                async with await get_db_connection() as db:
                     # Check if user is fresh (no referrer, no payments)
                     curr = await db.execute("SELECT referrer_id, (SELECT count(*) FROM payments WHERE user_id=users.user_id) as p_count FROM users WHERE user_id=?", (message.from_user.id,))
                     row = await curr.fetchone()
                     if row and row[0] is None and row[1] == 0:
                         await db.execute("UPDATE users SET referrer_id=? WHERE user_id=?", (int(ref_id), message.from_user.id))
                         await db.commit()
            except Exception:
                pass

    # Majburiy kanallar
    not_joined = await get_not_joined_channels(bot, message.from_user.id)
    if not_joined:
        text = "❌ Iltimos, quyidagi kanallarga a'zo bo'ling:\n\n"
        kb = InlineKeyboardBuilder()
        for name, url in not_joined:
            kb.button(text=name, url=url)
        kb.button(text="✅ A'zo bo'ldim", callback_data="check_subscription")
        kb.adjust(1)
        await message.answer(text, reply_markup=kb.as_markup())
        return

    # Obuna va admin tekshirish
    has_sub = await has_active_sub(message.from_user.id)
    is_admin = message.from_user.id == ADMIN_ID
    
    await message.answer("...", reply_markup=ReplyKeyboardRemove())
    
    if has_sub:
        await message.answer(
            "👋 <b>Xush kelibsiz!</b>\n\n"
            "✅ Obunangiz faol. Reklama yaratishni boshlang!",
            reply_markup=start_menu_kb(has_sub=True, is_admin=is_admin)
        )
    else:
        await message.answer(
            "👋 <b>Assalomu alaykum!</b>\n\n"
            "🚀 <b>AvtoReklama Bot</b> - Guruhlariga avtomatik reklama tarqatuvchi bot.\n\n"
            "Botdan foydalanish uchun obuna oling yoki 3 kun TEKIN sinab ko'ring:",
            reply_markup=start_menu_kb(has_sub=False, is_admin=is_admin)
        )

@router.callback_query(F.data == "check_subscription")
async def check_sub_handler(cb: types.CallbackQuery, bot: Bot):
    not_joined = await get_not_joined_channels(bot, cb.from_user.id)
    if not_joined:
        await cb.answer("❌ Hali hamma kanallarga a'zo bo'lmadingiz!", show_alert=True)
    else:
        await cb.message.delete()
        has_sub = await has_active_sub(cb.from_user.id)
        is_admin = cb.from_user.id == ADMIN_ID
        await cb.message.answer("✅ Rahmat!", reply_markup=start_menu_kb(has_sub, is_admin=is_admin))

@router.callback_query(F.data == "back_home")
async def back_home_handler(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    has_sub = await has_active_sub(cb.from_user.id)
    is_admin = cb.from_user.id == ADMIN_ID
    try:
        await cb.message.edit_text(
            "🏠 <b>Bosh Menyu</b>",
            reply_markup=start_menu_kb(has_sub)
        )
    except Exception:
        pass  # Xabar o'zgarmagan

# ==================== OSON USUL (YANGI) ====================
@router.callback_query(F.data == "easy_mode")
async def easy_mode_handler(cb: types.CallbackQuery, state: FSMContext):
    """Oson usul - tez va sodda"""
    if not await has_active_sub(cb.from_user.id):
        await cb.answer("❌ Obuna kerak!", show_alert=True)
        return
    
    # Akkaunt tekshirish
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", 
                              (cb.from_user.id,))
        acc = await cur.fetchone()
    
    if not acc:
        kb = InlineKeyboardBuilder()
        kb.button(text="🔗 Akkaunt Ulash", callback_data="add_account_start")
        kb.button(text="◀️ Orqaga", callback_data="back_home")
        kb.adjust(1)
        await cb.message.edit_text(
            "⚠️ <b>Avval akkaunt ulang!</b>\n\n"
            "Reklama yuborish uchun Telegram akkauntingizni ulashingiz kerak.",
            reply_markup=kb.as_markup()
        )
        return
    
    await state.update_data(session=acc[0])
    await state.set_state(SimpleFlow.waiting_text)
    
    await cb.message.edit_text(
        "🚀 <b>OSON USUL</b>\n\n"
        "📝 <b>1-Qadam:</b> Reklama matningizni yuboring:",
        reply_markup=back_kb()
    )

# ==================== PRO USUL ====================
@router.callback_query(F.data == "pro_mode")
async def pro_mode_handler(cb: types.CallbackQuery):
    """Pro usul - ko'proq imkoniyatlar"""
    if not await has_active_sub(cb.from_user.id):
        await cb.answer("❌ Obuna kerak!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="📝 Yangi Reklama", callback_data="create_ad_start")
    kb.button(text="📂 Reklamalarim", callback_data="ads_list")
    kb.button(text="🔗 Akkauntlar", callback_data="acc_menu")
    kb.button(text="👥 Guruhlar", callback_data="groups_menu")
    kb.button(text="⚙️ Sozlamalar", callback_data="settings_menu")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(2, 2, 2)
    
    await cb.message.edit_text(
        "💼 <b>PRO USUL</b>\n\n"
        "Ko'proq boshqaruv va imkoniyatlar:",
        reply_markup=kb.as_markup()
    )

@router.callback_query(F.data == "groups_menu")
async def groups_menu_handler(cb: types.CallbackQuery):
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT count(*) FROM groups WHERE user_id=?", (cb.from_user.id,))
        count = (await cur.fetchone())[0]
    
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Orqaga", callback_data="pro_mode")
    
    await cb.message.edit_text(
        f"👥 <b>Guruhlar</b>\n\n"
        f"Bazada: <b>{count}</b> ta guruh",
        reply_markup=kb.as_markup()
    )

@router.callback_query(F.data == "settings_menu")
async def settings_menu_handler(cb: types.CallbackQuery):
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Orqaga", callback_data="pro_mode")
    
    await cb.message.edit_text(
        "⚙️ <b>Sozlamalar</b>\n\n"
        "Hozircha sozlamalar yo'q.",
        reply_markup=kb.as_markup()
    )

# ==================== 3 KUN TEKIN ====================
@router.callback_query(F.data == "get_trial")
async def get_trial_handler(cb: types.CallbackQuery, state: FSMContext):
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT trial_used FROM users WHERE user_id=?", (cb.from_user.id,))
        row = await cur.fetchone()
        
        if row and row[0] == 1:
            await cb.answer("❌ Siz allaqachon tekin sinov davridan foydalangansiz!", show_alert=True)
            return
        
        # Trial aktivlashtirish
        now = datetime.utcnow()
        new_date = now + timedelta(days=3)
        
        await db.execute("UPDATE users SET paid_until=?, trial_used=1 WHERE user_id=?", 
                        (new_date.isoformat(), cb.from_user.id))
        await db.commit()
    
    await cb.message.edit_text(
        "🎉 <b>Tabriklaymiz!</b>\n\n"
        "Sizga 3 kunlik TEKIN sinov davri faollashtirildi!\n\n"
        "Endi reklama yaratishni boshlashingiz mumkin:",
        reply_markup=start_menu_kb(has_sub=True)
    )

# ==================== VIP OBUNA ====================
@router.callback_query(F.data == "buy_sub")
async def buy_sub_handler(cb: types.CallbackQuery, state: FSMContext):
    prices = {
        'hour': int(await get_settings_value("price_hour", "500")),
        'day': int(await get_settings_value("daily_price", "1000")),
        'week': int(await get_settings_value("price_week", "6000")),
        'month': int(await get_settings_value("price_month", "20000")),
        'year': int(await get_settings_value("price_year", "200000"))
    }
    
    kb = InlineKeyboardBuilder()
    kb.button(text=f"🕐 1 Soat - {prices['hour']} so'm", callback_data="sub_item:hour")
    kb.button(text=f"📅 1 Kun - {prices['day']} so'm", callback_data="sub_item:day")
    kb.button(text=f"🗓 1 Hafta - {prices['week']} so'm", callback_data="sub_item:week")
    kb.button(text=f"📆 1 Oy - {prices['month']} so'm", callback_data="sub_item:month")
    kb.button(text=f"🎉 1 Yil - {prices['year']} so'm", callback_data="sub_item:year")
    kb.button(text="🎁 3 Kun TEKIN (Trial)", callback_data="sub_item:trial")
    kb.button(text="🎟 Promokod kiritish", callback_data="enter_promo")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(1)
    
    await cb.message.edit_text(
        "💎 <b>VIP Obuna Paketlari</b>\n\n"
        "O'zingizga mos tarifni tanlang:\n\n"
        "💡 Promokodingiz bo'lsa, uni qo'llashingiz mumkin!",
        reply_markup=kb.as_markup()
    )

@router.callback_query(F.data.startswith("sub_item:"))
async def sub_item_handler(cb: types.CallbackQuery, state: FSMContext):
    ptype = cb.data.split(":")[1]
    
    # Trial
    if ptype == "trial":
        # get_trial ga yo'naltirish
        await get_trial_handler(cb, state)
        return
    
    # Narxlar
    from config import DEFAULT_HOURLY_PRICE, DEFAULT_DAILY_PRICE, DEFAULT_WEEKLY_PRICE, DEFAULT_MONTHLY_PRICE, DEFAULT_YEARLY_PRICE
    
    price_map = {
        "hour": (int(await get_settings_value("price_hour", str(DEFAULT_HOURLY_PRICE))), 1/24, "1 Soat"),
        "day": (int(await get_settings_value("daily_price", str(DEFAULT_DAILY_PRICE))), 1, "1 Kun"),
        "week": (int(await get_settings_value("price_week", str(DEFAULT_WEEKLY_PRICE))), 7, "1 Hafta"),
        "month": (int(await get_settings_value("price_month", str(DEFAULT_MONTHLY_PRICE))), 30, "1 Oy"),
        "year": (int(await get_settings_value("price_year", str(DEFAULT_YEARLY_PRICE))), 365, "1 Yil"),
    }
    
    if ptype not in price_map:
        await cb.answer("❌ Noto'g'ri tanlov", show_alert=True)
        return
    
    price, days, label = price_map[ptype]
    await state.update_data(days=days, amount=price, label=label)
    await state.set_state(PaymentStates.waiting_method)
    
    await cb.message.edit_text(
        f"✅ Tanlandi: <b>{label}</b>\n"
        f"💰 Summa: <b>{price} so'm</b>\n\n"
        "To'lov usulini tanlang:",
        reply_markup=payment_methods_kb()
    )

# ==================== TO'LOV USULLARI ====================
@router.callback_query(F.data.startswith("pay_method:"))
async def pay_method_handler(cb: types.CallbackQuery, state: FSMContext):
    method = cb.data.split(":")[1]
    data = await state.get_data()
    
    if not data.get('amount'):
        await cb.answer("❌ Avval obuna paketini tanlang!", show_alert=True)
        return
    
    amount = data['amount']
    days = data['days']
    label = data.get('label', '')
    
    if method == "rasmiypay":
        # RasmiyPay
        from utils.rasmiypay import RasmiyPayClient
        success, result = await RasmiyPayClient.create_order(amount)
        
        if success:
            order_id = result.get('order', result.get('data', {}).get('order', 'unknown'))
            
            async with await get_db_connection() as db:
                await db.execute(
                    "INSERT INTO payments (user_id, amount, days, payment_method, status, order_id) VALUES (?,?,?,?,?,?)",
                    (cb.from_user.id, amount, days, 'rasmiypay', 'pending', order_id)
                )
                await db.commit()
            
            kb = InlineKeyboardBuilder()
            kb.button(text="♻️ To'lovni Tekshirish", callback_data=f"check_pay:{order_id}")
            kb.button(text="◀️ Bekor qilish", callback_data="back_home")
            kb.adjust(1)
            
            await cb.message.edit_text(
                f"💳 <b>RasmiyPay To'lov</b>\n\n"
                f"🆔 Buyurtma: <code>{order_id}</code>\n"
                f"💰 Summa: {amount} so'm\n\n"
                "To'lovni amalga oshiring va 'Tekshirish' tugmasini bosing.",
                reply_markup=kb.as_markup()
            )
            await state.clear()
        else:
            await cb.message.edit_text(
                f"❌ Xatolik: {result}\n\n"
                "Iltimos, boshqa usulni tanlang:",
                reply_markup=payment_methods_kb()
            )
    
    elif method == "manual":
        # Manual to'lov
        card = await get_settings_value("admin_card", "0000 0000 0000 0000")
        await state.set_state(PaymentStates.waiting_cheque)
        
        kb = InlineKeyboardBuilder()
        kb.button(text="◀️ Bekor qilish", callback_data="back_home")
        kb.adjust(1)
        
        await cb.message.edit_text(
            f"💳 <b>Karta orqali To'lov</b>\n\n"
            f"📋 Karta: <code>{card}</code>\n"
            f"💰 Summa: <b>{amount} so'm</b>\n\n"
            "To'lov qilib, <b>chek rasmini</b> yuboring:",
            reply_markup=kb.as_markup()
        )

@router.callback_query(F.data.startswith("check_pay:"))
async def check_payment_handler(cb: types.CallbackQuery):
    order_id = cb.data.split(":")[1]
    
    from utils.rasmiypay import RasmiyPayClient
    success, data = await RasmiyPayClient.check_order(order_id)
    
    if not success:
        await cb.answer(f"❌ Xatolik: {data}", show_alert=True)
        return
    
    status = data.get("status", "unknown")
    
    if status == "paid":
        async with await get_db_connection() as db:
            cur = await db.execute("SELECT status, days FROM payments WHERE order_id=?", (order_id,))
            row = await cur.fetchone()
            
            if row and row[0] == 'approved':
                await cb.answer("✅ Bu to'lov allaqachon tasdiqlangan!", show_alert=True)
                return
            
            days = row[1] if row else 1
            
            await db.execute("UPDATE payments SET status='approved', approved_at=? WHERE order_id=?", 
                           (datetime.utcnow().isoformat(), order_id))
            
            # Obunani uzaytirish
            cur = await db.execute("SELECT paid_until FROM users WHERE user_id=?", (cb.from_user.id,))
            u_row = await cur.fetchone()
            
            now = datetime.utcnow()
            if u_row and u_row[0]:
                try:
                    curr = datetime.fromisoformat(u_row[0])
                    new_date = (curr if curr > now else now) + timedelta(days=days)
                except:
                    new_date = now + timedelta(days=days)
            else:
                new_date = now + timedelta(days=days)
            
            await db.execute("UPDATE users SET paid_until=? WHERE user_id=?", (new_date.isoformat(), cb.from_user.id))
            await db.commit()
        
        await cb.message.edit_text(
            f"🎉 <b>To'lov Muvaffaqiyatli!</b>\n\n"
            f"Sizga {days} kun obuna qo'shildi.\n"
            "Endi reklama yaratishni boshlang!",
            reply_markup=start_menu_kb(has_sub=True)
        )
    elif status == "pending":
        await cb.answer("⏳ To'lov hali kelib tushmadi. Biroz kuting.", show_alert=True)
    else:
        await cb.answer(f"❌ Status: {status}", show_alert=True)

@router.message(PaymentStates.waiting_cheque, F.photo)
async def manual_cheque_received(message: types.Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    days = data.get('days', 1)
    amount = data.get('amount', 0)
    
    async with await get_db_connection() as db:
        await db.execute(
            "INSERT INTO payments (user_id, amount, days, payment_method, status) VALUES (?,?,?,?,?)",
            (message.from_user.id, amount, days, 'manual', 'pending')
        )
        await db.commit()
    
    await message.answer(
        "✅ <b>Chek qabul qilindi!</b>\n\n"
        "Admin tekshirib, obunangizni faollashtiradi.\n"
        "Biroz kuting...",
        reply_markup=start_menu_kb(has_sub=False)
    )
    await state.clear()
    
    # Adminga yuborish
    caption = (
        f"💰 <b>Yangi To'lov</b>\n\n"
        f"👤 User: {message.from_user.id}\n"
        f"📛 Ism: {message.from_user.full_name}\n"
        f"📅 Kun: {days}\n"
        f"💵 Summa: {amount} so'm\n\n"
        f"✅ Tasdiqlash: /approve_{message.from_user.id}_{days}\n"
        f"❌ Rad etish: /reject_{message.from_user.id}"
    )
    try:
        await bot.send_photo(ADMIN_ID, photo=message.photo[-1].file_id, caption=caption)
    except Exception as e:
        print(f"Admin xabar xatosi: {e}")

# ==================== REKLAMA YARATISH ====================
@router.callback_query(F.data == "create_ad_start")
async def create_ad_start(cb: types.CallbackQuery, state: FSMContext):
    # Obuna tekshirish
    if not await has_active_sub(cb.from_user.id):
        await cb.answer("❌ Obunangiz tugagan! Yangi obuna oling.", show_alert=True)
        await cb.message.edit_text(
            "❌ Obunangiz tugagan!\n\nYangi obuna oling:",
            reply_markup=start_menu_kb(has_sub=False)
        )
        return
    
    # Akkaunt tekshirish
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", 
                              (cb.from_user.id,))
        acc = await cur.fetchone()
    
    if not acc:
        kb = InlineKeyboardBuilder()
        kb.button(text="🔗 Akkaunt Ulash", callback_data="add_account_start")
        kb.button(text="◀️ Orqaga", callback_data="back_home")
        kb.adjust(1)
        
        await cb.message.edit_text(
            "⚠️ <b>Akkaunt Kerak!</b>\n\n"
            "Reklama yuborish uchun Telegram akkauntingizni ulang.",
            reply_markup=kb.as_markup()
        )
        return
    
    await state.update_data(session=acc[0])
    await state.set_state(SimpleFlow.waiting_text)
    
    await cb.message.edit_text(
        "📝 <b>1-Qadam: Reklama Matni</b>\n\n"
        "Reklama matningizni yuboring:",
        reply_markup=back_kb()
    )

@router.message(SimpleFlow.waiting_text)
async def ad_text_received(message: types.Message, state: FSMContext):
    text = message.text
    if not text or len(text) < 3:
        await message.answer("❌ Matn juda qisqa!")
        return
    
    await state.update_data(ad_text=text)
    await state.set_state(SimpleFlow.waiting_photo)
    
    kb = InlineKeyboardBuilder()
    kb.button(text="⏭ Rasmsiz davom etish", callback_data="skip_photo")
    kb.adjust(1)
    
    await message.answer(
        "📷 <b>2-Qadam: Rasm (Ixtiyoriy)</b>\n\n"
        "Rasm yuboring yoki 'Rasmsiz davom etish' tugmasini bosing:",
        reply_markup=kb.as_markup()
    )

@router.message(SimpleFlow.waiting_photo, F.photo)
async def ad_photo_received(message: types.Message, state: FSMContext):
    os.makedirs(f"photos/{message.from_user.id}", exist_ok=True)
    file_path = f"photos/{message.from_user.id}/{message.message_id}.jpg"
    await message.bot.download(message.photo[-1], destination=file_path)
    
    await state.update_data(photo_path=file_path)
    await go_to_interval(message, state)

@router.callback_query(F.data == "skip_photo")
async def skip_photo_handler(cb: types.CallbackQuery, state: FSMContext):
    await state.update_data(photo_path=None)
    await go_to_interval_cb(cb, state)

async def go_to_interval(message: types.Message, state: FSMContext):
    await state.set_state(SimpleFlow.waiting_interval)
    await message.answer(
        "⏱ <b>3-Qadam: Interval</b>\n\n"
        "Xabar qanchada bir yuborilsin?",
        reply_markup=simple_intervals_kb()
    )

async def go_to_interval_cb(cb: types.CallbackQuery, state: FSMContext):
    await state.set_state(SimpleFlow.waiting_interval)
    await cb.message.edit_text(
        "⏱ <b>3-Qadam: Interval</b>\n\n"
        "Xabar qanchada bir yuborilsin?",
        reply_markup=simple_intervals_kb()
    )

@router.callback_query(SimpleFlow.waiting_interval, F.data.startswith("simple_interval:"))
async def interval_selected(cb: types.CallbackQuery, state: FSMContext):
    val = cb.data.split(":")[1]
    
    if val == "custom":
        await cb.message.edit_text(
            "📝 Intervalni soniyalarda yozing (masalan: 15):",
            reply_markup=back_kb()
        )
        await state.set_state(SimpleFlow.waiting_custom_interval)
        return
    
    await state.update_data(interval_sec=int(val))
    await go_to_groups(cb, state)

@router.message(SimpleFlow.waiting_custom_interval)
async def custom_interval_received(message: types.Message, state: FSMContext):
    try:
        interval = int(message.text.strip())
        if interval < 1:
            raise ValueError()
    except:
        await message.answer("❌ Raqam kiriting!")
        return
    
    await state.update_data(interval_sec=interval)
    await message.answer(
        "👥 <b>4-Qadam: Guruh Tanlash</b>\n\n"
        "Tanlash usulini belgilang:",
        reply_markup=group_method_kb()
    )
    await state.set_state(SimpleFlow.waiting_group_method)

async def go_to_groups(cb: types.CallbackQuery, state: FSMContext):
    await cb.message.edit_text(
        "👥 <b>4-Qadam: Guruh Tanlash</b>\n\n"
        "Tanlash usulini belgilang:",
        reply_markup=group_method_kb()
    )
    await state.set_state(SimpleFlow.waiting_group_method)

@router.callback_query(F.data.startswith("group_method:"))
async def group_method_handler(cb: types.CallbackQuery, state: FSMContext):
    method = cb.data.split(":")[1]
    data = await state.get_data()
    session = data.get('session')
    
    # Agar session state'da yo'q bo'lsa, DBdan olish
    if not session:
        async with await get_db_connection() as db:
            cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", 
                                  (cb.from_user.id,))
            acc = await cur.fetchone()
        
        if not acc:
            kb = InlineKeyboardBuilder()
            kb.button(text="🔗 Akkaunt Ulash", callback_data="add_account_start")
            kb.button(text="◀️ Orqaga", callback_data="back_home")
            kb.adjust(1)
            await cb.message.edit_text(
                "⚠️ <b>Akkaunt topilmadi!</b>\n\n"
                "Iltimos, avval akkaunt ulang.",
                reply_markup=kb.as_markup()
            )
            return
        
        session = acc[0]
        await state.update_data(session=session)
    
    if method == "keyword":
        await cb.message.edit_text(
            "🔍 <b>Kalit So'z</b>\n\n"
            "Guruh nomida qidirilsin kerak bo'lgan so'zni yozing:\n"
            "Masalan: <code>taxi</code>, <code>arenda</code>",
            reply_markup=back_kb()
        )
        await state.set_state(SimpleFlow.waiting_keyword)
        
    elif method == "all":
        from utils.telethon_utils import get_all_user_groups
        await cb.message.edit_text("⏳ Barcha guruhlar yuklanmoqda... Bir oz kuting.")
        
        try:
            groups = await get_all_user_groups(session)
        except Exception as e:
            await cb.message.edit_text(
                f"❌ <b>Xatolik yuz berdi!</b>\n\n"
                f"{str(e)}\n\n"
                f"Iltimos akkauntni 'Akkauntlar' bo'limidan o'chirib, qayta ulang.",
                reply_markup=back_kb()
            )
            return

        if not groups:
            await cb.message.edit_text(
                "❌ Guruhlar topilmadi.",
                reply_markup=group_method_kb()
            )
            return

        targets = [g['ref'] for g in groups]
        await state.update_data(targets=targets, target_type='manual')
        await show_summary_cb(cb, state, len(targets))
        
    elif method == "folder":
        from utils.telethon_utils import get_user_folders
        await cb.message.edit_text("📁 Jildlar yuklanmoqda...")
        
        try:
            folders = await get_user_folders(session)
        except Exception as e:
            await cb.message.edit_text(
                f"❌ <b>Xatolik yuz berdi!</b>\n\n"
                f"{str(e)}\n\n"
                f"Iltimos akkauntni 'Akkauntlar' bo'limidan o'chirib, qayta ulang.",
                reply_markup=back_kb()
            )
            return

        if not folders:
            await cb.message.edit_text(
                "❌ Jildlar topilmadi.\n\nBoshqa usulni tanlang:",
                reply_markup=group_method_kb()
            )
            return
        
        await cb.message.edit_text(
            "📁 <b>Jild Tanlang</b>:",
            reply_markup=folders_list_kb(folders)
        )
        await state.set_state(SimpleFlow.waiting_folder)
        
    elif method == "link" or method == "username":
        await cb.message.edit_text(
            "🔗 <b>Link/Username</b>\n\n"
            "Guruh link yoki username ni yozing:\n"
            "Masalan: <code>@guruh_nomi</code>\n\n"
            "Bir nechta bo'lsa, har birini yangi qatorga yozing.",
            reply_markup=back_kb()
        )
        await state.set_state(SimpleFlow.waiting_link)

@router.message(SimpleFlow.waiting_keyword)
async def keyword_received(message: types.Message, state: FSMContext):
    keyword = message.text.strip()
    if len(keyword) < 2:
        await message.answer("❌ Kamida 2 ta belgi!")
        return
    
    await message.answer("🔍 Qidirilmoqda...")
    
    data = await state.get_data()
    session = data.get('session')
    
    from utils.telethon_utils import search_groups_by_keyword
    groups = await search_groups_by_keyword(session, keyword)
    
    if not groups:
        await message.answer(
            f"❌ '{keyword}' so'zi bilan guruh topilmadi.",
            reply_markup=group_method_kb()
        )
        await state.set_state(SimpleFlow.waiting_group_method)
        return
    
    targets = [g['username'] for g in groups]
    await state.update_data(targets=targets, target_type='keyword')
    await show_summary(message, state, groups)

@router.callback_query(SimpleFlow.waiting_folder, F.data.startswith("select_folder:"))
async def folder_selected(cb: types.CallbackQuery, state: FSMContext):
    folder_id = int(cb.data.split(":")[1])
    data = await state.get_data()
    session = data.get('session')
    
    await cb.message.edit_text("📁 Yuklanmoqda...")
    
    from utils.telethon_utils import get_folder_peers
    peers = await get_folder_peers(session, folder_id)
    
    if not peers:
        await cb.message.edit_text(
            "❌ Bu jildda guruh topilmadi.",
            reply_markup=group_method_kb()
        )
        await state.set_state(SimpleFlow.waiting_group_method)
        return
    
    await state.update_data(targets=peers, target_type='folder')
    await show_summary_cb(cb, state, len(peers))

@router.message(SimpleFlow.waiting_link)
async def link_received(message: types.Message, state: FSMContext):
    lines = [l.strip() for l in message.text.split('\n') if l.strip()]
    if not lines:
        await message.answer("❌ Link yoki username kiriting!")
        return
    
    targets = []
    for line in lines:
        if "t.me/" in line:
            parts = line.split("t.me/")
            if len(parts) > 1:
                targets.append("@" + parts[1].replace("/", ""))
        elif line.startswith("@"):
            targets.append(line)
        else:
            targets.append("@" + line)
    
    await state.update_data(targets=targets, target_type='manual')
    await show_summary(message, state, None)

async def show_summary(message: types.Message, state: FSMContext, groups=None):
    data = await state.get_data()
    ad_text = data.get('ad_text', '')[:50]
    interval = data.get('interval_sec', 5)
    targets = data.get('targets', [])
    photo = "✅" if data.get('photo_path') else "❌"
    
    await message.answer(
        f"📋 <b>XULOSA</b>\n\n"
        f"📝 Matn: {ad_text}...\n"
        f"📷 Rasm: {photo}\n"
        f"⏱ Interval: {interval} soniya\n"
        f"👥 Guruhlar: {len(targets)} ta\n\n"
        "🚀 Boshlashga tayyormisiz?",
        reply_markup=confirm_start_kb()
    )

async def show_summary_cb(cb: types.CallbackQuery, state: FSMContext, count: int):
    data = await state.get_data()
    ad_text = data.get('ad_text', '')[:50]
    interval = data.get('interval_sec', 5)
    photo = "✅" if data.get('photo_path') else "❌"
    
    await cb.message.edit_text(
        f"📋 <b>XULOSA</b>\n\n"
        f"📝 Matn: {ad_text}...\n"
        f"📷 Rasm: {photo}\n"
        f"⏱ Interval: {interval} soniya\n"
        f"👥 Guruhlar: {count} ta\n\n"
        "🚀 Boshlashga tayyormisiz?",
        reply_markup=confirm_start_kb()
    )

@router.callback_query(F.data == "confirm_ad_start")
async def confirm_and_start(cb: types.CallbackQuery, state: FSMContext):
    if not await has_active_sub(cb.from_user.id):
        await cb.answer("❌ Obuna tugagan!", show_alert=True)
        return
    
    data = await state.get_data()
    ad_text = data.get('ad_text', '')
    photo_path = data.get('photo_path')
    interval_sec = data.get('interval_sec', 5)
    targets = data.get('targets', [])
    target_type = data.get('target_type', 'manual')
    
    if not targets:
        await cb.answer("❌ Guruhlar tanlanmagan!", show_alert=True)
        return
    
    # TAGLINE qo'shish
    full_text = f"{ad_text}\n\n{TAGLINE}" if TAGLINE else ad_text
    targets_str = '\n'.join(targets)
    
    async with await get_db_connection() as db:
        await db.execute(
            "INSERT INTO messages (user_id, text, photo_path, interval_sec, active, target_type, targets) VALUES (?,?,?,?,?,?,?)",
            (cb.from_user.id, full_text, photo_path, interval_sec, 1, target_type, targets_str)
        )
        await db.commit()
    
    await cb.message.edit_text(
        "🚀 <b>REKLAMA BOSHLANDI!</b>\n\n"
        f"⏱ Interval: {interval_sec} soniya\n"
        f"👥 Guruhlar: {len(targets)} ta\n\n"
        "Bot xabarlarni avtomatik yuborishni boshladi!",
        reply_markup=start_menu_kb(has_sub=True)
    )
    await state.clear()

# ==================== AKKAUNTLAR ====================
@router.callback_query(F.data == "acc_menu")
async def acc_menu_handler(cb: types.CallbackQuery):
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT phone FROM accounts WHERE user_id=? AND is_active=1", (cb.from_user.id,))
        rows = await cur.fetchall()
    
    text = "🔗 <b>Akkauntlar</b>\n\n"
    if rows:
        for r in rows:
            text += f"📱 +{r[0]}\n"
    else:
        text += "Hozircha akkaunt yo'q."
    
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Akkaunt Qo'shish", callback_data="add_account_start")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(1)
    
    await cb.message.edit_text(text, reply_markup=kb.as_markup())

@router.callback_query(F.data == "add_account_start")
async def add_account_start(cb: types.CallbackQuery, state: FSMContext):
    if not await has_active_sub(cb.from_user.id):
        await cb.answer("❌ Obuna kerak!", show_alert=True)
        return
    
    await cb.message.edit_text(
        "📱 <b>Akkaunt Qo'shish</b>\n\n"
        "Telefon raqamingizni yuboring:\n"
        "Masalan: +998901234567",
        reply_markup=back_kb()
    )
    await state.set_state(AccountStates.waiting_phone)

@router.message(AccountStates.waiting_phone)
async def phone_received(message: types.Message, state: FSMContext):
    phone = message.text.strip().replace(" ", "").replace("+", "")
    
    # StringSession bilan ishlash (file emas)
    from telethon.sessions import StringSession
    
    client = TelegramClient(StringSession(), API_ID, API_HASH)
    await client.connect()
    
    try:
        sent = await client.send_code_request(phone)
        
        # Session stringni saqlash
        session_string = client.session.save()
        
        await state.update_data(
            phone=phone, 
            phone_code_hash=sent.phone_code_hash,
            session_string=session_string
        )
        await state.set_state(AccountStates.waiting_code)
        
        await message.answer(
            f"✅ Kod yuborildi!\n\n"
            f"Telegramdan kelgan kodni kiriting:",
            reply_markup=back_kb()
        )
        await client.disconnect()
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")
        await client.disconnect()

@router.message(AccountStates.waiting_code)
async def code_received(message: types.Message, state: FSMContext):
    code = message.text.strip()
    data = await state.get_data()
    phone = data.get("phone")
    phone_code_hash = data.get("phone_code_hash")
    session_string = data.get("session_string")
    
    from telethon.sessions import StringSession
    
    client = TelegramClient(StringSession(session_string), API_ID, API_HASH)
    await client.connect()
    
    try:
        try:
            await client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
        except Exception as e:
            if "password" in str(e).lower():
                # Parol kerak - session ni yangilab saqlash
                new_session = client.session.save()
                await state.update_data(session_string=new_session)
                await state.set_state(AccountStates.waiting_password)
                await message.answer("🔒 Parolingizni kiriting:")
                await client.disconnect()
                return
            raise e
        
        # Akkaunt ma'lumotlarini olish
        me = await client.get_me()
        acc_username = me.username or str(me.id)
        
        # Final session stringni olish
        final_session = client.session.save()
        
        await client.disconnect()
        
        async with await get_db_connection() as db:
            await db.execute(
                "INSERT INTO accounts (user_id, phone, session_string, username, folder_path) VALUES (?,?,?,?,?)",
                (message.from_user.id, phone, final_session, acc_username, "")
            )
            await db.commit()
        
        has_sub = await has_active_sub(message.from_user.id)
        await message.answer(
            f"✅ Akkaunt ulandi!\n\n"
            f"👤 Username: @{acc_username}",
            reply_markup=start_menu_kb(has_sub)
        )
        await state.clear()
        
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")
        await client.disconnect()

@router.message(AccountStates.waiting_password)
async def password_received(message: types.Message, state: FSMContext):
    password = message.text.strip()
    data = await state.get_data()
    phone = data.get("phone")
    session_string = data.get("session_string")
    
    from telethon.sessions import StringSession
    
    client = TelegramClient(StringSession(session_string), API_ID, API_HASH)
    await client.connect()
    
    try:
        await client.sign_in(password=password)
        
        # Akkaunt ma'lumotlarini olish
        me = await client.get_me()
        acc_username = me.username or str(me.id)
        
        # Final session stringni olish
        final_session = client.session.save()
        
        await client.disconnect()
        
        async with await get_db_connection() as db:
            await db.execute(
                "INSERT INTO accounts (user_id, phone, session_string, username, folder_path) VALUES (?,?,?,?,?)",
                (message.from_user.id, phone, final_session, acc_username, "")
            )
            await db.commit()
        
        has_sub = await has_active_sub(message.from_user.id)
        await message.answer(
            f"✅ Akkaunt ulandi!\n\n"
            f"👤 Username: @{acc_username}",
            reply_markup=start_menu_kb(has_sub)
        )
        await state.clear()
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")
        await client.disconnect()

# ==================== REKLAMALARNI BOSHQARISH ====================
@router.callback_query(F.data == "ads_list")
async def ads_list_handler(cb: types.CallbackQuery):
    async with await get_db_connection() as db:
        cur = await db.execute(
            "SELECT id, text, active, interval_sec, sent_count, created_at, total_groups, success_count, fail_count FROM messages WHERE user_id=?", 
            (cb.from_user.id,)
        )
        rows = await cur.fetchall()
        logger.info(f"ADS_LIST_HANDLER: User {cb.from_user.id} requested ads. Found {len(rows)} rows.")
    
    if not rows:
        await cb.message.edit_text(
            "📂 <b>Sizda reklamalar yo'q.</b>\n\n"
            "Yangi reklama yaratish uchun 'Oson Usul' yoki 'Yangi Reklama' ni tanlang.",
            reply_markup=back_kb()
        )
        return

    text = "📂 <b>Mening Reklamalarim:</b>\n\n"
    kb = InlineKeyboardBuilder()
    
    for row in rows:
        mid, text_content, active, interval, sent, created_at, total_groups, success_count, fail_count = row
        status = "🟢 Aktiv" if active else "🔴 To'xtatilgan"
        short_text = (text_content or "")[:25].replace("\n", " ")
        
        # Ishlash vaqtini hisoblash
        running_time = "-"
        if created_at:
            try:
                created_dt = datetime.fromisoformat(created_at)
                diff = datetime.utcnow() - created_dt
                hours = int(diff.total_seconds() // 3600)
                minutes = int((diff.total_seconds() % 3600) // 60)
                if hours > 0:
                    running_time = f"{hours} soat {minutes} daqiqa"
                else:
                    running_time = f"{minutes} daqiqa"
            except:
                pass
        
        text += f"<b>ID: {mid}</b> | {status}\n"
        text += f"📝 {short_text}...\n"
        text += f"⏱ Interval: {interval}s\n"
        text += f"👥 Guruhlar: {total_groups or 0} ta\n"
        text += f"✅ Yuborildi: {success_count or 0} ta\n"
        text += f"❌ Xato: {fail_count or 0} ta\n"
        text += f"🕐 Ishlash vaqti: {running_time}\n"
        text += f"📊 Jami yuborish: {sent or 0} ta\n\n"
        
        action_text = "To'xtatish" if active else "Yoqish"
        kb.button(text=f"{'🛑' if active else '▶️'} #{mid} {action_text}", callback_data=f"toggle_ad:{mid}")
        kb.button(text=f"🗑 #{mid} O'chirish", callback_data=f"del_ad:{mid}")
    
    kb.button(text="📊 Statistika", callback_data="my_stats")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(2, 2) 
    
    try:
        await cb.message.edit_text(text, reply_markup=kb.as_markup())
    except Exception:
        pass  # Xabar o'zgarmagan

@router.callback_query(F.data == "my_stats")
async def my_stats_handler(cb: types.CallbackQuery):
    """Foydalanuvchi umumiy statistikasi"""
    user_id = cb.from_user.id
    
    async with await get_db_connection() as db:
        # Reklamalar statistikasi
        cur = await db.execute(
            "SELECT COUNT(*), SUM(sent_count), SUM(success_count), SUM(fail_count), SUM(total_groups) FROM messages WHERE user_id=?",
            (user_id,)
        )
        row = await cur.fetchone()
        total_ads, total_sent, total_success, total_fail, total_groups = row if row else (0, 0, 0, 0, 0)
        
        # Aktiv reklamalar
        cur = await db.execute("SELECT COUNT(*) FROM messages WHERE user_id=? AND active=1", (user_id,))
        active_ads = (await cur.fetchone())[0]
        
        # Akkauntlar
        cur = await db.execute("SELECT COUNT(*) FROM accounts WHERE user_id=? AND is_active=1", (user_id,))
        accounts = (await cur.fetchone())[0]
        
        # Obuna
        cur = await db.execute("SELECT paid_until FROM users WHERE user_id=?", (user_id,))
        u_row = await cur.fetchone()
        sub_status = "❌ Nofaol"
        sub_until = "-"
        if u_row and u_row[0]:
            try:
                until_dt = datetime.fromisoformat(u_row[0])
                if until_dt > datetime.utcnow():
                    sub_status = "✅ Faol"
                    sub_until = until_dt.strftime("%d.%m.%Y %H:%M")
                    # Qolgan vaqt
                    remaining = until_dt - datetime.utcnow()
                    days_left = remaining.days
                    hours_left = int(remaining.seconds // 3600)
                    sub_until += f" ({days_left} kun {hours_left} soat qoldi)"
            except:
                pass
    
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Orqaga", callback_data="ads_list")
    
    await cb.message.edit_text(
        f"📊 <b>Sizning Statistikangiz</b>\n\n"
        f"<b>🎯 Reklamalar:</b>\n"
        f"├ Jami: {total_ads or 0} ta\n"
        f"├ Aktiv: {active_ads or 0} ta\n"
        f"└ To'xtatilgan: {(total_ads or 0) - (active_ads or 0)} ta\n\n"
        f"<b>📤 Yuborishlar:</b>\n"
        f"├ Jami yuborildi: {total_sent or 0} ta\n"
        f"├ Muvaffaqiyatli: {total_success or 0} ta\n"
        f"├ Xatolar: {total_fail or 0} ta\n"
        f"└ Guruhlar: {total_groups or 0} ta\n\n"
        f"<b>👤 Akkaunt:</b>\n"
        f"└ Ulangan: {accounts} ta\n\n"
        f"<b>💎 Obuna:</b>\n"
        f"├ Holat: {sub_status}\n"
        f"└ Muddat: {sub_until}",
        reply_markup=kb.as_markup()
    )

@router.callback_query(F.data.startswith("toggle_ad:"))
async def toggle_ad_handler(cb: types.CallbackQuery):
    mid = int(cb.data.split(":")[1])
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT active FROM messages WHERE id=? AND user_id=?", (mid, cb.from_user.id))
        row = await cur.fetchone()
        if row:
            new_status = 0 if row[0] else 1
            await db.execute("UPDATE messages SET active=? WHERE id=?", (new_status, mid))
            await db.commit()
            status_msg = "to'xtatildi 🛑" if new_status == 0 else "yoqildi ✅"
            await cb.answer(f"Reklama {status_msg}")
            await ads_list_handler(cb)
        else:
            await cb.answer("❌ Reklama topilmadi!", show_alert=True)

@router.callback_query(F.data.startswith("del_ad:"))
async def delete_ad_handler(cb: types.CallbackQuery):
    mid = int(cb.data.split(":")[1])
    async with await get_db_connection() as db:
        await db.execute("DELETE FROM messages WHERE id=? AND user_id=?", (mid, cb.from_user.id))
        await db.commit()
    
    try:
        await cb.answer("🗑 Reklama o'chirildi!")
    except Exception:
        pass  # Query eskirgan
    await ads_list_handler(cb)

# ==================== BOSHQA ====================
@router.callback_query(F.data == "profile")
async def profile_handler(cb: types.CallbackQuery):
    user_id = cb.from_user.id
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT balance, paid_until FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
    
    if not row:
        await cb.answer("❌ Profil topilmadi!", show_alert=True)
        return
    
    balance, paid_until = row
    status = "❌ Nofaol"
    until_str = "-"
    
    if paid_until:
        try:
            until_dt = datetime.fromisoformat(paid_until)
            if until_dt > datetime.utcnow():
                status = "✅ VIP Faol"
                until_str = until_dt.strftime("%d.%m.%Y %H:%M")
            else:
                status = "❌ Tugagan"
        except:
            pass
    
    has_sub = await has_active_sub(user_id)
    
    await cb.message.edit_text(
        f"👤 <b>Profilingiz</b>\n\n"
        f"🆔 ID: <code>{user_id}</code>\n"
        f"💰 Balans: {balance} so'm\n"
        f"📊 Status: {status}\n"
        f"⏳ Muddat: {until_str}",
        reply_markup=start_menu_kb(has_sub)
    )

@router.callback_query(F.data == "ads_list")
async def ads_list_handler(cb: types.CallbackQuery):
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT id, text, interval_sec, active FROM messages WHERE user_id=?", (cb.from_user.id,))
        rows = await cur.fetchall()
    
    has_sub = await has_active_sub(cb.from_user.id)
    
    if not rows:
        await cb.message.edit_text("📭 Sizda reklamalar yo'q.", reply_markup=start_menu_kb(has_sub))
        return
    
    text = "📂 <b>Reklamalaringiz:</b>\n\n"
    for id, msg_text, interval, active in rows:
        status = "🟢" if active else "🔴"
        short = (msg_text[:25] + "..") if len(msg_text) > 25 else msg_text
        text += f"{status} #{id} | {interval}s | {short}\n"
    
    await cb.message.edit_text(text, reply_markup=start_menu_kb(has_sub))

@router.callback_query(F.data == "support")
async def support_handler(cb: types.CallbackQuery):
    has_sub = await has_active_sub(cb.from_user.id)
    await cb.message.edit_text(
        f"🆘 <b>Yordam</b>\n\n"
        f"Admin: <a href='tg://user?id={ADMIN_ID}'>Bu yerga bosing</a>",
        reply_markup=start_menu_kb(has_sub)
    )

@router.callback_query(F.data == "admin_panel")
async def admin_panel_handler(cb: types.CallbackQuery):
    if cb.from_user.id == ADMIN_ID:
        from keyboards.admin_kb import admin_menu_kb
        await cb.message.edit_text("⚙️ Admin Panel", reply_markup=admin_menu_kb())
    else:
        await cb.answer("❌ Ruxsat yo'q!", show_alert=True)

# ==================== PROMO ====================
# ==================== PROMO ====================
@router.callback_query(F.data == "enter_promo")
async def enter_promo_callback(cb: types.CallbackQuery, state: FSMContext):
    await state.set_state(PaymentStates.waiting_promo_input)
    await cb.message.edit_text(
        "🎟 <b>Promokod Kiritish</b>\n\n"
        "Promokodni yuboring (masalan: <code>START5</code>):",
        reply_markup=back_kb()
    )

@router.message(PaymentStates.waiting_promo_input)
async def promo_input_handler(message: types.Message, state: FSMContext):
    code = message.text.upper().strip()
    
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT days, activations_left FROM promocodes WHERE code=?", (code,))
        row = await cur.fetchone()
        
        if not row:
            await message.answer("❌ Bunday promokod yo'q yoki xato yozdingiz.", reply_markup=back_kb())
            return
        
        days, left = row
        if left <= 0:
            await message.answer("❌ Bu promokod tugagan.", reply_markup=back_kb())
            return
        
        u_cur = await db.execute("SELECT 1 FROM promo_usage WHERE user_id=? AND code=?", (message.from_user.id, code))
        if await u_cur.fetchone():
            await message.answer("❌ Siz bu promokodni allaqachon ishlatgansiz.", reply_markup=back_kb())
            return
        
        # Apply promo
        await db.execute("INSERT INTO promo_usage (user_id, code) VALUES (?,?)", (message.from_user.id, code))
        await db.execute("UPDATE promocodes SET activations_left = activations_left - 1 WHERE code=?", (code,))
        
        now = datetime.utcnow()
        cur = await db.execute("SELECT paid_until FROM users WHERE user_id=?", (message.from_user.id,))
        u_row = await cur.fetchone()
        
        if u_row and u_row[0]:
            try:
                curr = datetime.fromisoformat(u_row[0])
                new_date = (curr if curr > now else now) + timedelta(days=days)
            except:
                new_date = now + timedelta(days=days)
        else:
            new_date = now + timedelta(days=days)
        
        await db.execute("UPDATE users SET paid_until=? WHERE user_id=?", (new_date.isoformat(), message.from_user.id))
        await db.commit()
    
    await state.clear()
    await message.answer(
        f"🎉 <b>Tabriklaymiz!</b>\n\n"
        f"Promokod muvaffaqiyatli aktivlashtirildi!\n"
        f"💎 Qo'shildi: <b>+{days} kun</b> obuna.",
        reply_markup=start_menu_kb(has_sub=True)
    )

@router.message(Command("promo"))
async def promo_handler(message: types.Message):
    try:
        code = message.text.split()[1].upper()
    except IndexError:
        await message.answer("Masalan: /promo START5")
        return

    # Reuse logic? Or copy-paste for safety to avoid circular deps if refactoring
    # Let's keep it clean
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT days, activations_left FROM promocodes WHERE code=?", (code,))
        row = await cur.fetchone()
        
        if not row:
            await message.answer("❌ Bunday promokod yo'q.")
            return
        
        days, left = row
        if left <= 0:
            await message.answer("❌ Promokod tugagan.")
            return
        
        u_cur = await db.execute("SELECT 1 FROM promo_usage WHERE user_id=? AND code=?", (message.from_user.id, code))
        if await u_cur.fetchone():
            await message.answer("❌ Siz bu promokodni ishlatgansiz.")
            return
        
        await db.execute("INSERT INTO promo_usage (user_id, code) VALUES (?,?)", (message.from_user.id, code))
        await db.execute("UPDATE promocodes SET activations_left = activations_left - 1 WHERE code=?", (code,))
        
        now = datetime.utcnow()
        cur = await db.execute("SELECT paid_until FROM users WHERE user_id=?", (message.from_user.id,))
        u_row = await cur.fetchone()
        
        if u_row and u_row[0]:
            try:
                curr = datetime.fromisoformat(u_row[0])
                new_date = (curr if curr > now else now) + timedelta(days=days)
            except:
                new_date = now + timedelta(days=days)
        else:
            new_date = now + timedelta(days=days)
        
        await db.execute("UPDATE users SET paid_until=? WHERE user_id=?", (new_date.isoformat(), message.from_user.id))
        await db.commit()
    
    await message.answer(f"✅ Promokod aktivlashtirildi! +{days} kun", reply_markup=start_menu_kb(has_sub=True))

# ================= REFFERALS =================
@router.callback_query(F.data == "referrals_menu")
async def referrals_menu_handler(cb: types.CallbackQuery):
    bot_info = await cb.bot.get_me()
    link = f"https://t.me/{bot_info.username}?start={cb.from_user.id}"
    
    async with await get_db_connection() as db:
        count = (await (await db.execute("SELECT COUNT(*) FROM users WHERE referrer_id=?", (cb.from_user.id,))).fetchone())[0]
        
    await safe_edit(cb,
        f"🔗 <b>Referallar Tizimi</b>\n\n"
        f"Do'stlaringizni taklif qiling va har bir to'lov qilgan do'stingiz uchun <b>+1 kun</b> obuna oling!\n\n"
        f"👤 Sizning takliflaringiz: {count} ta\n\n"
        f"👇 Sizning havolangiz:\n<code>{link}</code>",
        reply_markup=back_kb()
    )

# ================= AUTO JOINER (SCRAPER) =================
@router.callback_query(F.data == "scraper_menu")
async def scraper_menu_handler(cb: types.CallbackQuery, state: FSMContext):
    # Select Account
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT phone, session_string FROM accounts WHERE user_id=? AND is_active=1", (cb.from_user.id,))
        rows = await cur.fetchall()
        
    if not rows:
        await cb.answer("❌ Ulanilgan akkaunt yo'q!", show_alert=True)
        return
        
    kb = InlineKeyboardBuilder()
    for phone, sess in rows:
        kb.button(text=f"📱 {phone}", callback_data=f"sel_scrape_acc:{phone}")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(1)
    
    await safe_edit(cb, "🤖 <b>Guruh Yig'ish (Auto-Joiner)</b>\n\nQaysi akkaunt orqali guruhlarga qo'shilmoqchisiz?", reply_markup=kb.as_markup())
    await state.set_state(ScraperStates.waiting_account)

@router.callback_query(ScraperStates.waiting_account, F.data.startswith("sel_scrape_acc:"))
async def scraper_acc_selected(cb: types.CallbackQuery, state: FSMContext):
    phone = cb.data.split(":")[1]
    # Fetch session
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND phone=?", (cb.from_user.id, phone))
        row = await cur.fetchone()
        
    if not row:
        await cb.answer("❌ Xatolik", show_alert=True)
        return
        
    await state.update_data(session=row[0])
    
    # Keyword entry
    kb = InlineKeyboardBuilder()
    presets = ["Taxi", "Arenda", "Logistika", "Elonlar"]
    for p in presets:
        kb.button(text=p, callback_data=f"scrape_key:{p}")
    kb.button(text="◀️ Orqaga", callback_data="scraper_menu")
    kb.adjust(2)
    
    await safe_edit(cb, 
        "🔍 <b>Qidiruv So'zi</b>\n\n"
        "Qaysi mavzudagi guruhlarni qidiramiz?\n"
        "Tayyorlardan tanlang yoki yozib yuboring:", 
        reply_markup=kb.as_markup()
    )
    await state.set_state(ScraperStates.waiting_keyword)

@router.message(ScraperStates.waiting_keyword)
async def scraper_key_input(message: types.Message, state: FSMContext):
    await start_scraper_task(message, state, message.text)

@router.callback_query(ScraperStates.waiting_keyword, F.data.startswith("scrape_key:"))
async def scraper_key_cb(cb: types.CallbackQuery, state: FSMContext):
    key = cb.data.split(":")[1]
    await start_scraper_task(cb.message, state, key)

async def start_scraper_task(message: types.Message, state: FSMContext, keyword: str):
    data = await state.get_data()
    session = data.get("session")
    
    await state.clear()
    
    # Create Task DB
    async with await get_db_connection() as db:
        cur = await db.execute(
            "INSERT INTO join_tasks (user_id, session_string, keyword) VALUES (?,?,?)",
            (message.chat.id, session, keyword)
        )
        task_id = cur.lastrowid
        await db.commit()
        
    # Start Background Task
    asyncio.create_task(start_join_task(task_id))
    
    msg_answer = message if isinstance(message, types.Message) else message.message
    await msg_answer.edit_text(
        f"✅ <b>Guruh yig'ish boshlandi!</b>\n\n"
        f"🔍 Mavzu: {keyword}\n"
        f"🤖 Bot orqa fonda guruhlarni qidirib, AI orqali tekshirib, sekin-asta qo'shiladi.\n"
        f"⚠️ Bu jarayon bir necha soat davom etishi mumkin.",
        reply_markup=back_kb()
    )
