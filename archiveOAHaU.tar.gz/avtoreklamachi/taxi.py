from telethon import TelegramClient, events
from telethon.tl.types import User
import asyncio
import json
from datetime import datetime, timedelta

# API ma'lumotlarini kiriting
api_id = "20245388"
api_hash = "494389e155bd7d18e8656de2c4973073"
phone_number = '+998948987722'

# Reklama matni
REKLAMA_MATNI = """
Assalomu aleykum! 👋

Taklifim bor edi

Sizni kutamiz! 🚗
"""

# Sozlamalar
GURUH_KALIT_SOZLAR = ['taxi', 'taksi']  # Qidirilishi kerak bo'lgan kalit so'zlar
XABAR_ORASIDAGI_VAQT = 60  # Har bir xabar orasida kutish vaqti (sekundlarda)
KUNLIK_LIMIT = 50  # Kuniga yuborilishi mumkin bo'lgan maksimal xabarlar soni

client = TelegramClient('userbot_session', api_id, api_hash)

# Xabar yuborilgan foydalanuvchilarni saqlash
yuborilgan_foydalanuvchilar = set()
kutilayotgan_foydalanuvchilar = set()  # YANGI: Jarayonda bo'lganlar
bugungi_xabarlar_soni = 0
oxirgi_reset_vaqti = datetime.now()

def yukla_foydalanuvchilar():
    """Avval xabar yuborilgan foydalanuvchilarni yuklash"""
    try:
        with open('yuborilgan_foydalanuvchilar.json', 'r') as f:
            data = json.load(f)
            return set(data.get('foydalanuvchilar', [])), data.get('bugungi_soni', 0)
    except FileNotFoundError:
        return set(), 0

def saqlash_foydalanuvchilar():
    """Foydalanuvchilar ro'yxatini saqlash"""
    with open('yuborilgan_foydalanuvchilar.json', 'w') as f:
        json.dump({
            'foydalanuvchilar': list(yuborilgan_foydalanuvchilar),
            'bugungi_soni': bugungi_xabarlar_soni,
            'oxirgi_yangilanish': str(datetime.now())
        }, f, ensure_ascii=False, indent=2)

async def xabar_yuborish(user_id):
    """Foydalanuvchiga shaxsiy xabar yuborish"""
    global bugungi_xabarlar_soni
    
    try:
        await client.send_message(user_id, REKLAMA_MATNI)
        yuborilgan_foydalanuvchilar.add(user_id)
        bugungi_xabarlar_soni += 1
        saqlash_foydalanuvchilar()
        print(f"✅ Xabar yuborildi: {user_id} | Bugungi jami: {bugungi_xabarlar_soni}")
        return True
    except Exception as e:
        print(f"❌ Xatolik {user_id}: {str(e)}")
        return False
    finally:
        # Kutilayotganlar ro'yxatidan o'chirish
        kutilayotgan_foydalanuvchilar.discard(user_id)

async def yuborish_vazifasi(user_id):
    """Alohida xabar yuborish vazifasi"""
    await asyncio.sleep(XABAR_ORASIDAGI_VAQT)
    await xabar_yuborish(user_id)

@client.on(events.NewMessage)
async def xabar_tutuvchi(event):
    """Guruhlardan yangi xabarlarni kuzatish"""
    global bugungi_xabarlar_soni, oxirgi_reset_vaqti
    
    # Kunlik limitni tekshirish va reset qilish
    if datetime.now() - oxirgi_reset_vaqti > timedelta(days=1):
        bugungi_xabarlar_soni = 0
        oxirgi_reset_vaqti = datetime.now()
        saqlash_foydalanuvchilar()
    
    # Kunlik limitga erishilganligini tekshirish
    if bugungi_xabarlar_soni >= KUNLIK_LIMIT:
        return
    
    # Faqat guruh xabarlarini qabul qilish
    if not event.is_group:
        return
    
    # Xabar matnida kalit so'zlar borligini tekshirish
    xabar_matni = event.message.text.lower() if event.message.text else ""
    if not any(kalit_soz in xabar_matni for kalit_soz in GURUH_KALIT_SOZLAR):
        return
    
    # Xabar yuborgan foydalanuvchini aniqlash
    sender = await event.get_sender()
    if not isinstance(sender, User) or sender.bot:
        return
    
    user_id = sender.id
    
    # MUHIM: Avval xabar yuborilgan yoki kutilayotganligini tekshirish
    if user_id in yuborilgan_foydalanuvchilar or user_id in kutilayotgan_foydalanuvchilar:
        return
    
    # Darhol kutilayotganlar ro'yxatiga qo'shish
    kutilayotgan_foydalanuvchilar.add(user_id)
    
    print(f"🔍 Yangi potensial mijoz topildi: {user_id}")
    
    # Xabar yuborish (asinxron vazifa sifatida)
    asyncio.create_task(yuborish_vazifasi(user_id))

async def main():
    """Asosiy funksiya"""
    global yuborilgan_foydalanuvchilar, bugungi_xabarlar_soni
    
    print("🤖 Userbot ishga tushmoqda...")
    
    # Avvalgi ma'lumotlarni yuklash
    yuborilgan_foydalanuvchilar, bugungi_xabarlar_soni = yukla_foydalanuvchilar()
    
    await client.start(phone=phone_number)
    print("✅ Userbot ishga tushdi!")
    print(f"📊 Bugungi yuborilgan xabarlar: {bugungi_xabarlar_soni}/{KUNLIK_LIMIT}")
    print(f"👥 Jami yuborilgan foydalanuvchilar: {len(yuborilgan_foydalanuvchilar)}")
    print("\n🔍 Guruhlarni kuzatish boshlandi...\n")
    
    await client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())