import aiosqlite
import logging
from datetime import datetime

DB_NAME = "bot.db"
logger = logging.getLogger(__name__)

async def init_db():
    async with aiosqlite.connect(DB_NAME) as db:
        # Users Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                is_admin INTEGER DEFAULT 0,
                paid_until DATETIME,
                balance INTEGER DEFAULT 0,
                trial_used INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                full_name TEXT,
                username TEXT
            )
            """
        )

        # Accounts Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                phone TEXT,
                session_string TEXT,
                username TEXT,
                folder_path TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_active INTEGER DEFAULT 1
            )
            """
        )
        
        # Accounts jadvaliga yangi ustunlar qo'shish (migration)
        try:
            await db.execute("ALTER TABLE accounts ADD COLUMN username TEXT")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE accounts ADD COLUMN folder_path TEXT")
        except Exception:
            pass

        # Groups Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                group_id TEXT,
                group_name TEXT,
                is_active INTEGER DEFAULT 1
            )
            """
        )

        # Messages Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                text TEXT,
                photo_path TEXT,
                interval_sec INTEGER DEFAULT 60,
                last_sent DATETIME,
                active INTEGER DEFAULT 0,
                sent_count INTEGER DEFAULT 0,
                target_type TEXT DEFAULT 'all', -- 'all', 'manual'
                targets TEXT -- JSON list or newline separated string of usernames/ids
            )
            """
        )

        # Migration for existing tables (if needed manually run logic, but here inside init is fine for new setup, 
        # for existing DB we might need alter statements if user persists DB)
        try:
            await db.execute("ALTER TABLE messages ADD COLUMN target_type TEXT DEFAULT 'all'")
            await db.execute("ALTER TABLE messages ADD COLUMN targets TEXT")
        except Exception:
            pass # Columns already exist
            
        try:
            await db.execute("ALTER TABLE users ADD COLUMN interface_mode TEXT DEFAULT 'simple'")
        except Exception:
            pass
        
        # New stats columns for messages
        try:
            await db.execute("ALTER TABLE messages ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE messages ADD COLUMN total_groups INTEGER DEFAULT 0")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE messages ADD COLUMN success_count INTEGER DEFAULT 0")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE messages ADD COLUMN fail_count INTEGER DEFAULT 0")
        except Exception:
            pass

        # Referral Migration
        try:
            await db.execute("ALTER TABLE users ADD COLUMN referrer_id INTEGER")
        except Exception:
            pass

        # Join Tasks Table (Auto-Joiner)
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS join_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                session_string TEXT,
                keyword TEXT,
                status TEXT DEFAULT 'running', -- running, completed, stopped
                found_count INTEGER DEFAULT 0,
                joined_count INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

        # Payments Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount INTEGER,
                days INTEGER,
                payment_method TEXT DEFAULT 'manual', -- 'manual' or 'rasmiypay'
                status TEXT DEFAULT 'pending', -- pending, approved, rejected, paid
                order_id TEXT, -- For API
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                approved_at DATETIME,
                admin_note TEXT
            )
            """
        )

        # Settings Table (Key-Value storage)
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            """
        )

        # Promocodes Table
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS promocodes (
                code TEXT PRIMARY KEY,
                days INTEGER,
                activations_left INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        
        # Mandatory Channels
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id TEXT,
                channel_url TEXT,
                channel_name TEXT
            )
            """
        )

        # Promocode Usage
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS promo_usage (
                user_id INTEGER,
                code TEXT,
                used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, code)
            )
            """
        )

        # Ensure default settings exist
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('daily_price', '1000')")
        # New prices
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('price_hour', '500')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('price_week', '6000')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('price_month', '20000')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('price_year', '200000')")
        
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('admin_card', '0000 0000 0000 0000')")
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('auto_pay_active', '1')") # 1 = On, 0 = Off
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('trial_days', '3')")

        await db.commit()

async def get_db_connection():
    return aiosqlite.connect(DB_NAME)
