﻿from aiogram import Router, F, types
from aiogram.filters import Command
from database.db import get_db_connection
from config import TAGLINE
from utils.link_parser import LinkParser
import json
import logging

router = Router()
logger = logging.getLogger(__name__)

@router.message(F.web_app_data)
async def web_app_data_handler(message: types.Message):
    """WebApp dan kelgan ma'lumotlarni qayta ishlash"""
    logger.info(f"=== WEB_APP_DATA RECEIVED ===")
    logger.info(f"From user: {message.from_user.id}")
    logger.info(f"Raw data: {message.web_app_data.data}")
    
    try:
        data = json.loads(message.web_app_data.data)
        logger.info(f"Parsed data: {data}")
        
        if data.get("action") == "create_ad":
            text = data.get("text", "")
            interval_sec = int(data.get("interval", 30))
            # Method handling ...
            method = data.get("target_type") or data.get("method", "all")
            targets_raw = data.get("targets", "")
            photo_path = data.get("photo") # Extract photo path/id
            
            logger.info(f"Method: {method}, Targets: {targets_raw}, Photo: {photo_path}")
            
            if not text.strip() and not photo_path:
                await message.answer("⚠️ Matn yoki rasm kiritilmagan!")
                return
            
            # ... (parsing logic) ...
            
                # Join with newline
                parsed_targets = '\n'.join(valid_links)
                logger.info(f"Parsed {len(valid_links)} valid links")
            
            # Save to DB
            async with await get_db_connection() as db:
                await db.execute(
                    "INSERT INTO messages (user_id, text, photo_path, interval_sec, active, target_type, targets) VALUES (?,?,?,?,?,?,?)",
                    (message.from_user.id, full_text, photo_path, interval_sec, 1, target_type, parsed_targets)
                )
                await db.commit()
            
            if target_type == "all":
                type_text = "📁 Barcha guruhlar"
            elif target_type == "folder":
                type_text = f"📂 Jild ID: {parsed_targets}"
            else:
                links_count = len(parsed_targets.split('\n')) if parsed_targets else 0
                type_text = f"📝 {links_count} ta kanal/guruh"
                
            await message.answer(
                f"✅ <b>Reklama qo'shildi!</b>\n\n"
                f"📝 Matn: {text[:30]}...\n"
                f"⏱ Interval: {interval_sec} soniya\n"
                f"🎯 Target: {type_text}\n"
                f"🟢 Holat: Aktiv"
            )
            logger.info(f"SUCCESS: Ad created for user {message.from_user.id}")
        else:
            logger.warning(f"Unknown action: {data.get('action')}")
            
    except Exception as e:
        logger.error(f"WebApp handler error: {e}", exc_info=True)
        await message.answer(f"❌ Xatolik yuz berdi. Iltimos qaytadan urinib ko'ring.")
