from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

def admin_menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    
    # 10+ Functions
    # 1. Stats
    kb.button(text="📊 Statistika", callback_data="admin_stats")
    # 2. Broadcast
    kb.button(text="📢 Xabar Yuborish", callback_data="admin_broadcast")
    # 3. Search User
    kb.button(text="🔍 User Qidirish", callback_data="admin_search_user")
    # 4. Add Balance
    kb.button(text="💰 Balans Qo'shish", callback_data="admin_add_balance")
    # 5. Block/Unblock
    kb.button(text="🚫 Ban/Unban", callback_data="admin_ban_user")
    # 6. Manage Channels
    kb.button(text="📢 Kanallar (Majburiy)", callback_data="admin_channels")
    # 7. Payment Settings
    kb.button(text="⚙️ To'lov Sozlamalari", callback_data="admin_pay_settings")
    # 8. Manage Requests
    kb.button(text="🧾 To'lovlar", callback_data="admin_pending_payments")
    # 9. Promocodes
    kb.button(text="🎁 Promokodlar", callback_data="admin_promocodes")
    # 10. Gift Sub
    kb.button(text="🎁 Obuna Sovg'a", callback_data="admin_gift_sub")
    
    kb.button(text="◀️ Chiqish", callback_data="back_home")
    
    kb.adjust(2, 2, 2, 2, 2, 1)
    return kb.as_markup()

def admin_pay_settings_kb(auto_pay: bool) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    auto_status = "✅ Yoqilgan" if auto_pay else "❌ O'chirilgan"
    
    kb.button(text=f"Avto To'lov: {auto_status}", callback_data="toggle_auto_pay")
    kb.button(text="💳 Kartani O'zgartirish", callback_data="edit_admin_card")
    kb.button(text="◀️ Orqaga", callback_data="admin_panel")
    kb.adjust(1)
    return kb.as_markup()

def admin_channel_management_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Kanal qo'shish", callback_data="admin_add_channel")
    kb.button(text="➖ Kanal o'chirish", callback_data="admin_del_channel")
    kb.button(text="📋 Ro'yxat", callback_data="admin_list_channels")
    kb.button(text="◀️ Orqaga", callback_data="admin_panel")
    kb.adjust(2, 1, 1)
    return kb.as_markup()
