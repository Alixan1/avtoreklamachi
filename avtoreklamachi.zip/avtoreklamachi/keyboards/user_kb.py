from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from config import WEBAPP_URL

# ============ ESKI 1-USUL (PRO REJIM) ============
def main_menu_inline_kb(is_admin: bool = False) -> InlineKeyboardMarkup:
    """Pro rejim bosh menyusi"""
    kb = InlineKeyboardBuilder()
    
    kb.button(text="🚀 Reklama Boshlash", callback_data="ads_menu")
    kb.button(text="👤 Kabinet / Profil", callback_data="profile")
    kb.button(text="🔗 Akkauntlar", callback_data="acc_menu")
    kb.button(text="👥 Guruhlar", callback_data="groups_menu")
    kb.button(text="🤖 Guruh Yig'ish (Auto)", callback_data="scraper_menu")
    kb.button(text="💎 VIP Obuna", callback_data="buy_sub")
    kb.button(text="📚 Qo'llanma", callback_data="instructions")
    kb.button(text="🆘 Yordam", callback_data="support")
    
    if is_admin:
        kb.button(text="⚙️ Admin Panel", callback_data="admin_panel")
        
    sizes = [2, 2, 2, 1]
    if is_admin:
        sizes.append(1)
        
    kb.adjust(*sizes)
    return kb.as_markup()

def ads_menu_kb() -> InlineKeyboardMarkup:
    """Reklama boshqaruv menyusi"""
    kb = InlineKeyboardBuilder()
    kb.button(text="✨ Yangi Xabar Yaratish", callback_data="ads_new")
    kb.button(text="📂 Mening Xabarlarim", callback_data="ads_list")
    kb.button(text="🔗 Akkauntlar", callback_data="acc_menu")
    kb.button(text="👥 Guruhlar", callback_data="groups_menu")
    kb.button(text="🏠 Bosh menyu", callback_data="back_home")
    kb.adjust(2, 2, 1)
    return kb.as_markup()

def intervals_kb() -> InlineKeyboardMarkup:
    """Eski interval tanlash (daqiqalar)"""
    kb = InlineKeyboardBuilder()
    intervals = [15, 20, 30, 45, 60, 120]
    for min in intervals:
        kb.button(text=f"{min} daqiqa", callback_data=f"set_interval:{min}")
    kb.button(text="◀️ Bekor qilish", callback_data="ads_menu")
    kb.adjust(2, 2, 2, 1)
    return kb.as_markup()

# ============ YANGI 2-USUL (ODDIY OQIM) ============
def start_menu_kb() -> InlineKeyboardMarkup:
    """
    /start bosilganda chiqadigan menyu
    2 ta usulni tanlash
    """
    kb = InlineKeyboardBuilder()
    kb.button(text="🚀 Tez Boshlash (Yangi)", callback_data="quick_start")
    kb.button(text="💼 Pro Rejim (Ko'proq imkoniyat)", callback_data="pro_mode")
    kb.button(text="🔗 Referallar", callback_data="referrals_menu")
    kb.button(text="👤 Profilim", callback_data="profile")
    kb.button(text="🆘 Yordam", callback_data="support")
    kb.adjust(1, 1, 1, 2)
    return kb.as_markup()

def subscription_packages_kb(prices: dict) -> InlineKeyboardMarkup:
    """Obuna paketlari"""
    kb = InlineKeyboardBuilder()
    
    kb.button(text=f"🕐 1 Soat - {prices.get('hour', 500)} so'm", callback_data="sub_item:hour")
    kb.button(text=f"📅 1 Kun - {prices.get('day', 1000)} so'm", callback_data="sub_item:day")
    kb.button(text=f"🗓 1 Hafta - {prices.get('week', 6000)} so'm", callback_data="sub_item:week")
    kb.button(text=f"📆 1 Oy - {prices.get('month', 20000)} so'm", callback_data="sub_item:month")
    kb.button(text=f"🎉 1 Yil - {prices.get('year', 200000)} so'm", callback_data="sub_item:year")
    kb.button(text="🎁 3 Kun TEKIN (Trial)", callback_data="sub_item:trial")
    
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(1)
    return kb.as_markup()

def simple_intervals_kb() -> InlineKeyboardMarkup:
    """
    Yangi oqim uchun interval tanlash (SONIYALAR)
    2, 3, 5, 6, 31 soniya + o'zi kiritish
    """
    kb = InlineKeyboardBuilder()
    
    # Soniyalar
    intervals = [2, 3, 5, 6, 10, 31]
    for sec in intervals:
        kb.button(text=f"⏱ {sec} soniya", callback_data=f"simple_interval:{sec}")
    
    # O'zi kiritish
    kb.button(text="📝 O'zim kiritaman", callback_data="simple_interval:custom")
    kb.button(text="◀️ Bekor qilish", callback_data="back_home")
    kb.adjust(3, 3, 1, 1)
    return kb.as_markup()

def group_method_kb() -> InlineKeyboardMarkup:
    """
    Guruh tanlash usullari:
    1. Kalit so'z (taxi, arenda)
    2. Jild orqali
    3. Link/ID
    4. Username
    """
    kb = InlineKeyboardBuilder()
    
    kb.button(text="🔍 Kalit so'z bilan topish", callback_data="group_method:keyword")
    kb.button(text="🌐 Barcha guruhlarim", callback_data="group_method:all")
    kb.button(text="📁 Jildlarimdan tanlash", callback_data="group_method:folder")
    kb.button(text="🔗 Link/ID kiritish", callback_data="group_method:link")
    kb.button(text="👤 Username kiritish", callback_data="group_method:username")
    kb.button(text="◀️ Orqaga", callback_data="back_home")
    kb.adjust(1)
    return kb.as_markup()

def folders_list_kb(folders: list) -> InlineKeyboardMarkup:
    """
    Foydalanuvchi jildlari ro'yxati
    folders = [{'id': 1, 'title': 'Ishlar'}, ...]
    """
    kb = InlineKeyboardBuilder()
    
    for folder in folders:
        kb.button(text=f"📁 {folder['title']}", callback_data=f"select_folder:{folder['id']}")
    
    kb.button(text="◀️ Orqaga", callback_data="group_method_back")
    kb.adjust(1)
    return kb.as_markup()

def confirm_start_kb() -> InlineKeyboardMarkup:
    """Reklamani boshlashni tasdiqlash"""
    kb = InlineKeyboardBuilder()
    kb.button(text="🚀 BOSHLASH", callback_data="confirm_ad_start")
    kb.button(text="◀️ Bekor qilish", callback_data="back_home")
    kb.adjust(1)
    return kb.as_markup()

def payment_methods_kb() -> InlineKeyboardMarkup:
    """To'lov usullari"""
    kb = InlineKeyboardBuilder()
    kb.button(text="💳 RasmiyPay (Avto)", callback_data="pay_method:rasmiypay")
    kb.button(text="🧾 Chek orqali (Manual)", callback_data="pay_method:manual")
    kb.button(text="◀️ Bekor qilish", callback_data="back_home")
    kb.adjust(1)
    return kb.as_markup()

def back_kb(callback_data: str = "back_home") -> InlineKeyboardMarkup:
    """Orqaga tugmasi"""
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️ Orqaga", callback_data=callback_data)
    return kb.as_markup()

# Eski simple_menu_kb (endi start_menu_kb ishlatiladi)
def simple_menu_kb() -> InlineKeyboardMarkup:
    """Eski oddiy menyu - endi start_menu_kb ga redirect"""
    return start_menu_kb()
