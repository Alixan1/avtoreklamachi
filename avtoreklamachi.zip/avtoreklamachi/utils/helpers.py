import logging
from datetime import datetime, timedelta
from database.db import get_db_connection
from aiogram import Bot
from config import ADMIN_ID

logger = logging.getLogger(__name__)

async def get_settings_value(key: str, default: str = None):
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
        return row[0] if row else default

async def ensure_user(user_id: int, full_name: str, username: str) -> None:
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT 1 FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row:
            is_admin = 1 if user_id == ADMIN_ID else 0
            
            # Default no sub, allow trial claim later
            paid_until = None
            
            await db.execute(
                "INSERT OR IGNORE INTO users(user_id, is_admin, paid_until, balance, trial_used, full_name, username) VALUES(?,?,?,?,?,?,?)",
                (user_id, is_admin, paid_until, 0, 0, full_name, username),
            )
            await db.commit()

async def has_active_sub(user_id: int) -> bool:
    """Obuna tekshiruvi - admin yoki pullik obuna"""
    # Admin har doim ruxsat
    if user_id == ADMIN_ID:
        return True

    async with await get_db_connection() as db:
        cur = await db.execute("SELECT paid_until FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row or not row[0]:
            return False
        try:
            return datetime.fromisoformat(row[0]) > datetime.utcnow()
        except Exception:
            return False

async def check_mandatory_channels(bot: Bot, user_id: int) -> bool:
    """Returns True if user is subscribed to all mandatory channels"""
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT channel_id FROM channels")
        channels = await cur.fetchall()
    
    if not channels:
        return True
        
    for (channel_id,) in channels:
        try:
            member = await bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            if member.status in ['left', 'kicked', 'banned']:
                return False
        except Exception as e:
            logger.warning(f"Error checking channel {channel_id}: {e}")
            # If bot can't check (not admin), we might skip or fail. 
            # Let's assume strict check, return False if cant check.
            # But if channel is invalid, we shouldn't block user.
            continue 
            
    return True

async def get_not_joined_channels(bot: Bot, user_id: int) -> list:
    """Returns list of (name, url) for channels user hasn't joined"""
    async with await get_db_connection() as db:
        cur = await db.execute("SELECT channel_id, channel_name, channel_url FROM channels")
        channels = await cur.fetchall()
        
    not_joined = []
    for ch_id, ch_name, ch_url in channels:
        try:
            member = await bot.get_chat_member(chat_id=ch_id, user_id=user_id)
            if member.status in ['left', 'kicked', 'banned']:
                not_joined.append((ch_name, ch_url))
        except Exception:
            # If check fails, assume not joined or skip?
            # Safer to skip requirement if bot has issue
            pass
            
    return not_joined
