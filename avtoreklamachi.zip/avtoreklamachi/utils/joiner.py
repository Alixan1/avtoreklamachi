import asyncio
import logging
import random
import urllib.parse
import aiohttp
from telethon import TelegramClient
from telethon.tl.functions.contacts import SearchRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import Channel
from telethon.sessions import StringSession
from telethon.errors import FloodWaitError
from config import API_ID, API_HASH
from database.db import get_db_connection

logger = logging.getLogger(__name__)
AI_API_URL = "https://apis.prexzyvilla.site/ai/chat"

async def ask_ai(title, about):
    """AI dan guruh haqida so'rash"""
    prompt = (
        f"Analyze this telegram group:\n"
        f"Title: {title}\n"
        f"Description: {about}\n"
        "Question: Is this a Taxi/Ride-sharing/Delivery/Freight group in Uzbekistan? "
        "Answer ONLY 'HA' (Yes) or 'YOQ' (No). "
        "Rules: Ignore religious, political, porn, or spam groups. Only transport/logistics."
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            encoded_prompt = urllib.parse.quote(prompt)
            url = f"{AI_API_URL}?prompt={encoded_prompt}&model=gpt-4"
            async with session.get(url, timeout=10) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return _parse_ai_response(data)
                else:
                    logger.warning(f"AI API Fail: {resp.status}")
    except Exception as e:
        logger.error(f"AI Error: {e}")
    return False

def _parse_ai_response(data):
    if isinstance(data, dict):
        answer = data.get('answer') or data.get('response') or data.get('result') or str(data)
    else:
        answer = str(data)
    answ_upper = str(answer).upper()
    return "HA" in answ_upper or "YES" in answ_upper

async def start_join_task(task_id: int):
    """Orqa fonda guruhga qo'shilish"""
    logger.info(f"Join Task {task_id} started")
    
    async with await get_db_connection() as db:
        row = await (await db.execute("SELECT session_string, keyword, user_id FROM join_tasks WHERE id=?", (task_id,))).fetchone()
        
    if not row:
        return
        
    session_str, keyword, user_id = row
    
    try:
        client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
        await client.connect()
        
        if not await client.is_user_authorized():
            logger.error(f"Task {task_id}: Session invalid")
            await _update_status(task_id, "failed")
            return

        joined_count = 0
        found_count = 0
        
        # Search
        try:
            result = await client(SearchRequest(q=keyword, limit=20))
            found_count = len(result.chats)
            
            # DB update found count
            async with await get_db_connection() as db:
                await db.execute("UPDATE join_tasks SET found_count=? WHERE id=?", (found_count, task_id))
                await db.commit()

            for chat in result.chats:
                if not isinstance(chat, Channel): continue
                if chat.left: # Not joined
                    title = chat.title
                    about = getattr(chat, 'about', '') or ''
                    
                    # AI Check
                    is_safe = await ask_ai(title, about)
                    
                    if is_safe:
                        try:
                            await client(JoinChannelRequest(chat))
                            joined_count += 1
                            logger.info(f"Task {task_id}: Joined {title}")
                            
                            # DB Update progress
                            async with await get_db_connection() as db:
                                await db.execute("UPDATE join_tasks SET joined_count=? WHERE id=?", (joined_count, task_id))
                                await db.commit()
                                
                            # Delay
                            delay = random.randint(60, 180)
                            await asyncio.sleep(delay)
                        except FloodWaitError as e:
                            logger.warning(f"FloodWait: {e.seconds}")
                            await asyncio.sleep(e.seconds)
                        except Exception as e:
                            logger.error(f"Join error: {e}")
                            
            await _update_status(task_id, "completed")
            
        except Exception as e:
            logger.error(f"Search error: {e}")
            await _update_status(task_id, "error")
            
    except Exception as e:
        logger.error(f"Task Crash: {e}")
        await _update_status(task_id, "crashed")
    finally:
        await client.disconnect()

async def _update_status(task_id, status):
    async with await get_db_connection() as db:
        await db.execute("UPDATE join_tasks SET status=? WHERE id=?", (status, task_id))
        await db.commit()
