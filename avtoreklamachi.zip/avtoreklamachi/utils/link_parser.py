import re

class LinkParser:
    @staticmethod
    def parse_targets(text: str) -> list:
        """
        Parses text and returns a list of unique usernames or IDs.
        Handles:
        - https://t.me/username
        - @username
        - t.me/username
        - username
        - https://t.me/+InviteLink (skipped or handled?) -> Sending to invite link is impossible via API usually, need entity.
        - -100123... (IDs)
        """
        if not text:
            return []
            
        # Split by whitespace, commas, newlines
        tokens = re.split(r'[\s,]+', text)
        targets = set()
        
        for token in tokens:
            token = token.strip()
            if not token: continue
            
            # Remove t.me/ https://t.me/
            clean = re.sub(r'^(https?://)?(www\.)?(t\.me|telegram\.me)/', '', token)
            
            # Remove @
            clean = clean.lstrip('@')
            
            # Check if it looks like a username or ID
            # Username: 5+ chars, a-z0-9_
            # ID: -100... or just digits
            
            if re.match(r'^-?\d+$', clean):
                targets.add(clean) # It's an ID
            elif re.match(r'^[a-zA-Z][a-zA-Z0-9_]{4,}$', clean):
                 targets.add("@" + clean) # Add @ back for consistency
            elif "+" in clean:
                # Invite link hash, can't send directly to hash usually without joining.
                # Skip for now or keep as is?
                # Using telethon we might need to resolve it.
                # Let's keep it as is, maybe resolving happens later.
                pass 
                
        return list(targets)
